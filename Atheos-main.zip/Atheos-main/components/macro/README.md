# Macro

This plugin adds some kind of macro functionallity to Codiad